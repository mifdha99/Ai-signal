package com.mifdha99.universalsignal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

private val Bg = Color(0xFF0B1020)
private val Panel = Color(0xFF151D30)
private val Muted = Color(0xFF9CAAC2)
private val Green = Color(0xFF27D69B)
private val Red = Color(0xFFFF5D70)
private val Blue = Color(0xFF69A7FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SignalScreen() } }
    }
}

data class Candle(val time: Long, val close: Double, val high: Double, val low: Double, val volume: Double)
data class SignalResult(
    val side: String,
    val price: Double,
    val rsi: Double,
    val emaFast: Double,
    val emaSlow: Double,
    val macd: Double,
    val reason: String,
    val time: String
)

@Composable
fun SignalScreen() {
    val scope = rememberCoroutineScope()
    val assets = listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT")
    val frames = listOf("1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h")
    var asset by remember { mutableStateOf("BTCUSDT") }
    var frame by remember { mutableStateOf("5m") }
    var loading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<SignalResult?>(null) }
    var error by remember { mutableStateOf("") }
    var expandedAsset by remember { mutableStateOf(false) }
    var expandedFrame by remember { mutableStateOf(false) }
    var updatedAt by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("UNIVERSAL SIGNAL AI", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(5.dp))
        Text("SINYAL TEKNIKAL • MODE ANALISIS", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(22.dp))

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("PILIH ASET KRIPTO", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { expandedAsset = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(asset, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(expanded = expandedAsset, onDismissRequest = { expandedAsset = false }) {
                        assets.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { asset = item; expandedAsset = false; result = null; error = "" })
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("TIMEFRAME", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Box {
                    OutlinedButton(onClick = { expandedFrame = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(frame, color = Color.White, fontSize = 17.sp)
                    }
                    DropdownMenu(expanded = expandedFrame, onDismissRequest = { expandedFrame = false }) {
                        frames.forEach { item ->
                            DropdownMenuItem(text = { Text(item) }, onClick = { frame = item; expandedFrame = false; result = null; error = "" })
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = {
                        loading = true; error = ""; result = null
                        scope.launch {
                            try {
                                val candles = withContext(Dispatchers.IO) { fetchCandles(asset, frame) }
                                result = analyze(candles)
                                updatedAt = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
                            } catch (e: Exception) {
                                error = "Data tidak berhasil diambil. Periksa internet atau coba lagi. (${e.message ?: "koneksi gagal"})"
                            } finally { loading = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = !loading,
                    colors = ButtonDefaults.buttonColors(containerColor = Blue),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(if (loading) "MENGANALISIS..." else "ANALISIS SEKARANG", color = Color(0xFF07101F), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(Modifier.height(18.dp))
        if (loading) {
            CircularProgressIndicator(color = Blue)
            Spacer(Modifier.height(10.dp))
            Text("Mengambil data harga dan menghitung indikator…", color = Muted)
        }
        if (error.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A1B2A))) {
                Text(error, color = Color.White, modifier = Modifier.padding(16.dp))
            }
        }
        result?.let { r ->
            val isBuy = r.side == "BUY"
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = if (isBuy) Color(0xFF103B35) else Color(0xFF421F2B)),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("HASIL ANALISIS", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(r.side, color = if (isBuy) Green else Red, fontSize = 46.sp, fontWeight = FontWeight.Black)
                    Text("$asset • $frame", color = Color.White, fontSize = 15.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Harga terakhir: ${"%.6f".format(Locale.US, r.price)}", color = Color.White)
                    Text("Waktu analisis: ${r.time}", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("RINGKASAN INDIKATOR", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    MetricRow("RSI (14)", "%.2f".format(Locale.US, r.rsi))
                    MetricRow("EMA (9)", "%.6f".format(Locale.US, r.emaFast))
                    MetricRow("EMA (21)", "%.6f".format(Locale.US, r.emaSlow))
                    MetricRow("MACD", "%.6f".format(Locale.US, r.macd))
                    Spacer(Modifier.height(10.dp))
                    Text(r.reason, color = Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("Diperbarui: $updatedAt", color = Muted, fontSize = 11.sp)
        }

        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text("PENTING", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Versi awal ini memakai data candle publik Binance untuk aset kripto spot. Sinyal BUY/SELL adalah keluaran aturan teknikal, bukan jaminan profit dan bukan prediksi akurasi 90%. Belum mendukung forex, saham, OTC, atau eksekusi transaksi.",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Gunakan dengan risiko yang terukur.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun MetricRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 14.sp)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun fetchCandles(symbol: String, interval: String): List<Candle> {
    val encoded = URLEncoder.encode(symbol, "UTF-8")
    val url = URL("https://api.binance.com/api/v3/klines?symbol=$encoded&interval=$interval&limit=250")
    val connection = (url.openConnection() as java.net.HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 12000
        readTimeout = 12000
        setRequestProperty("User-Agent", "UniversalSignalAI/1.0")
    }
    try {
        if (connection.responseCode !in 200..299) throw IllegalStateException("HTTP ${connection.responseCode}")
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val array = JSONArray(body)
        val candles = mutableListOf<Candle>()
        for (i in 0 until array.length()) {
            val row = array.getJSONArray(i)
            candles += Candle(
                time = row.getLong(0),
                high = row.getString(2).toDouble(),
                low = row.getString(3).toDouble(),
                close = row.getString(4).toDouble(),
                volume = row.getString(5).toDouble()
            )
        }
        if (candles.size < 60) throw IllegalStateException("Data historis tidak cukup")
        // Binance's final kline may still be forming; omit it to avoid using a partial candle.
        return candles.dropLast(1)
    } finally {
        connection.disconnect()
    }
}

private fun analyze(candles: List<Candle>): SignalResult {
    require(candles.size >= 60) { "Data historis tidak cukup" }
    val closes = candles.map { it.close }
    val ema9 = ema(closes, 9)
    val ema21 = ema(closes, 21)
    val ema50 = ema(closes, 50)
    val rsi = rsi(closes, 14)
    val macdLine = ema(closes, 12) - ema(closes, 26)
    val signalLine = emaSeries(closes, 12).zip(emaSeries(closes, 26)) { a, b -> a - b }.let { ema(it, 9) }
    val macdHist = macdLine - signalLine
    val recent = closes.last()
    val prior = closes[closes.lastIndex - 1]
    val momentumUp = recent > prior
    val bullish = ema9 > ema21 && ema21 > ema50 && rsi in 52.0..68.0 && macdHist > 0 && momentumUp
    val bearish = ema9 < ema21 && ema21 < ema50 && rsi in 32.0..48.0 && macdHist < 0 && !momentumUp
    val side = when {
        bullish -> "BUY"
        bearish -> "SELL"
        // The requested output is only BUY or SELL. If indicators conflict, choose the side
        // with the larger normalized directional vote; this does NOT imply high confidence.
        directionalScore(ema9, ema21, ema50, rsi, macdHist, momentumUp) >= 0 -> "BUY"
        else -> "SELL"
    }
    val reason = when {
        bullish -> "Tren EMA bertingkat naik, RSI mendukung momentum, MACD positif, dan candle terakhir menguat."
        bearish -> "Tren EMA bertingkat turun, RSI mendukung momentum, MACD negatif, dan candle terakhir melemah."
        else -> "Indikator belum sepakat. Arah dipilih dari suara gabungan tren, RSI, MACD, dan momentum; sinyal ini lebih lemah dan bukan konfirmasi kuat."
    }
    return SignalResult(
        side, recent, rsi, ema9, ema21, macdHist, reason,
        SimpleDateFormat("HH:mm:ss dd-MM-yyyy", Locale.getDefault()).format(Date())
    )
}

private fun directionalScore(e9: Double, e21: Double, e50: Double, rsi: Double, macd: Double, momentumUp: Boolean): Double {
    var score = 0.0
    if (e9 > e21) score += 1.0 else score -= 1.0
    if (e21 > e50) score += 1.0 else score -= 1.0
    if (rsi >= 50.0) score += 1.0 else score -= 1.0
    if (macd > 0) score += 1.0 else score -= 1.0
    if (momentumUp) score += 0.5 else score -= 0.5
    return score
}

private fun ema(values: List<Double>, period: Int): Double = emaSeries(values, period).last()
private fun emaSeries(values: List<Double>, period: Int): List<Double> {
    require(values.isNotEmpty())
    val k = 2.0 / (period + 1.0)
    val out = ArrayList<Double>(values.size)
    var current = values.first()
    out += current
    for (i in 1 until values.size) {
        current = values[i] * k + current * (1.0 - k)
        out += current
    }
    return out
}
private fun rsi(values: List<Double>, period: Int): Double {
    require(values.size > period)
    var gains = 0.0
    var losses = 0.0
    for (i in 1..period) {
        val diff = values[i] - values[i - 1]
        if (diff > 0) gains += diff else losses -= diff
    }
    var avgGain = gains / period
    var avgLoss = losses / period
    for (i in (period + 1) until values.size) {
        val diff = values[i] - values[i - 1]
        val gain = if (diff > 0) diff else 0.0
        val loss = if (diff < 0) -diff else 0.0
        avgGain = (avgGain * (period - 1) + gain) / period
        avgLoss = (avgLoss * (period - 1) + loss) / period
    }
    if (avgLoss == 0.0) return 100.0
    val rs = avgGain / avgLoss
    return 100.0 - (100.0 / (1.0 + rs))
}
