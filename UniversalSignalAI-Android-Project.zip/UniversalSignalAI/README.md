# Universal Signal AI (Android)

Aplikasi Android Native Kotlin dengan tampilan sederhana untuk analisis teknikal aset kripto spot.

## Fitur versi awal
- Pilih aset kripto spot: BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT, XRPUSDT, DOGEUSDT.
- Timeframe Binance: 1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h.
- Mengambil candle publik dari Binance.
- Menghitung EMA 9/21/50, RSI 14, dan MACD.
- Menghasilkan satu label BUY atau SELL sesuai permintaan UI.

## Batasan yang harus diketahui
- Versi awal ini **hanya untuk data kripto spot Binance**. Belum universal untuk forex, saham, komoditas, indeks, binary options, atau OTC.
- Timeframe detik tidak disediakan oleh endpoint candle Binance yang dipakai.
- BUY/SELL adalah hasil aturan teknikal sederhana, bukan jaminan profit. Tidak ada klaim akurasi 90%; perlu backtest dan forward test independen sebelum dipakai dengan uang sungguhan.
- Jika indikator tidak searah, aplikasi tetap memilih BUY atau SELL sesuai permintaan, tetapi menandai alasan bahwa sinyal lebih lemah. Ini berisiko; jangan menganggapnya sinyal kuat.
- Aplikasi tidak mengeksekusi transaksi.
- API publik dapat membatasi permintaan atau tidak tersedia di wilayah tertentu.

## Build APK via GitHub Actions
1. Buat repositori GitHub baru, misalnya `UniversalSignalAI`.
2. Upload seluruh isi folder proyek ini ke root repositori, termasuk folder `.github/workflows`.
3. Buka tab **Actions**.
4. Pilih **Build Android APK**, lalu tekan **Run workflow** (atau tunggu build berjalan setelah push).
5. Buka workflow yang selesai, bagian **Artifacts**, lalu unduh `UniversalSignalAI-debug-apk`.
6. Ekstrak ZIP artifact dan instal `app-debug.apk` di Android. Izinkan instalasi dari sumber yang kamu pilih bila diminta.

## Catatan
Untuk distribusi publik, buat APK release yang ditandatangani dengan keystore sendiri dan simpan rahasianya sebagai GitHub Secrets. Jangan mengunggah keystore atau password ke repositori publik.
